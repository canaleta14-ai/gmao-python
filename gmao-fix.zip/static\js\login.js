document.addEventListener('DOMContentLoaded', function () {
    document.body.classList.add('login-bg');
});
