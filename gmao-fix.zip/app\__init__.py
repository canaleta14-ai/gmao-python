# Inicialización del paquete app
from .factory import create_app
