# Inicialización del paquete config
